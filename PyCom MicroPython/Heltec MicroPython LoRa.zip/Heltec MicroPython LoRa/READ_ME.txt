robert-hh Port of PyCom MicroPython for Heltec failed (Following is the latest command I have used to write the firmware)
esptool.py --chip esp32 --port COM8 erase_flash
esptool.py --chip esp32 --port COM8 --baud 460800 --after no_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0x1000 bootloader.bin 0x8000 partitions_8MB.bin 0x10000 heltec.bin

esptool.py --chip esp32 --port COM8 --baud 460800 --after no_reset write_flash -z --flash_size detect 0x1000 bootloader.bin 0x8000 partitions_8MB.bin 0x10000 heltec.bin



pip install wxpython
pip install pyinstaller
pip install esptool

Tensilica LX6 dual-core
